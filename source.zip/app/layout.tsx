import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Reference FX Desk · ECB 기준환율",
  description: "실제 ECB 기준환율과 KST 조회 기록, 데이터 실패 상태를 확인합니다.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">{children}</body>
    </html>
  );
}
