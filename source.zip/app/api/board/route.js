import {env} from 'cloudflare:workers';
import worker from '../../../worker.mjs';
export async function GET(request){return worker.fetch(request,env);}
