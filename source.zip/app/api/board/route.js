import {env} from 'cloudflare:workers';
import {board} from '../../../lib/d1.mjs';
export async function GET(){try{return Response.json(await board(env.DB),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'storage_unavailable',message:'기록 저장소에 연결하지 못했습니다. 잠시 후 다시 시도해 주세요.'},{status:503});}}
