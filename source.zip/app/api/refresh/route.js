import {env} from 'cloudflare:workers';
import {refreshBoard} from '../../../lib/service.mjs';
export async function POST(request){
 if(request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'origin'},{status:403});
 try{return Response.json(await refreshBoard(env.DB),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'storage_unavailable'},{status:503});}
}
