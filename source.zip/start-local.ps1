$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskNode=Get-Command node -ErrorAction SilentlyContinue
if($taskNode){$taskNodePath=$taskNode.Source}else{$taskNodePath=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'}
if(!(Test-Path -LiteralPath $taskNodePath)){throw 'Node.js 22.13 이상을 먼저 설치해 주세요.'}
& $taskNodePath build-public.mjs;if($LASTEXITCODE -ne 0){throw '화면 빌드 실패'}
& $taskNodePath server-local.mjs
