import {DatabaseSync} from 'node:sqlite';
export class LocalD1{
 constructor(file){this.db=new DatabaseSync(file);}
 prepare(sql){const db=this.db;let args=[];const s={bind(...values){args=values;return s;},async all(){return {results:db.prepare(sql).all(...args)};},async first(){return db.prepare(sql).get(...args)||null;},async run(){const r=db.prepare(sql).run(...args);return {meta:{changes:Number(r.changes)}};}};return s;}
 async batch(statements){this.db.exec('BEGIN IMMEDIATE');try{const r=[];for(const s of statements)r.push(await s.run());this.db.exec('COMMIT');return r;}catch(e){this.db.exec('ROLLBACK');throw e;}}
 close(){this.db.close();}
}
