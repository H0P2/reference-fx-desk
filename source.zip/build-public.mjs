import {build} from 'esbuild';import {mkdir,cp,writeFile} from 'node:fs/promises';
await mkdir('dist/client',{recursive:true});await mkdir('dist/server',{recursive:true});await cp('public','dist/client',{recursive:true});
await build({entryPoints:['client.jsx'],bundle:true,outfile:'dist/client/app.js',jsx:'automatic',minify:true,define:{'process.env.NODE_ENV':'"production"'},platform:'browser'});
await build({entryPoints:['worker.mjs'],bundle:true,outfile:'dist/server/index.js',format:'esm',platform:'neutral',target:'es2022'});
await writeFile('dist/client/index.html','<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Reference FX Desk · ECB 기준환율</title><link rel="icon" href="/favicon.svg"><link rel="stylesheet" href="/app.css"></head><body><div id="root"></div><script type="module" src="/app.js"></script></body></html>');
await writeFile('dist/server/wrangler.json',JSON.stringify({name:'reference-fx-desk',main:'index.js',compatibility_date:'2026-05-15',assets:{directory:'../client',binding:'ASSETS',run_worker_first:['/api/*']},d1_databases:[{binding:'DB',database_name:'site-creator-d1',database_id:'00000000-0000-4000-8000-000000000000',migrations_dir:'../../drizzle'}]},null,2));
console.log('Public client and D1 Worker built.');
