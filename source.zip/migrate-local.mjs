import {readFile,readdir} from 'node:fs/promises';
export async function migrateLocal(db){
 db.db.exec('CREATE TABLE IF NOT EXISTS local_migrations(name TEXT PRIMARY KEY)');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort()){
  if(db.db.prepare('SELECT name FROM local_migrations WHERE name=?').get(file))continue;
  const previous=db.db.prepare('SELECT name FROM local_migrations LIMIT 1').get();
  const legacy=file==='0000_married_mockingbird.sql'&&!previous&&db.db.prepare("SELECT name FROM sqlite_master WHERE name='readings'").get();
  db.db.exec('BEGIN IMMEDIATE');try{if(!legacy)db.db.exec(await readFile('drizzle/'+file,'utf8'));db.db.prepare('INSERT INTO local_migrations VALUES(?)').run(file);db.db.exec('COMMIT');}catch(e){db.db.exec('ROLLBACK');throw e;}
 }
}
