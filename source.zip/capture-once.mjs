// Backward-compatible entry point using the same observer and learning storage.
await import('./observe-once.mjs');
