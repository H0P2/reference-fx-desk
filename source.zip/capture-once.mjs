import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {fetchECB,HISTORY_URL,parseRates} from './lib/ecb.mjs';
import {save,board} from './lib/d1.mjs';import {LocalD1} from './local-db.mjs';import {createHash} from 'node:crypto';
import {migrateLocal} from './migrate-local.mjs';
await mkdir('data',{recursive:true});const db=new LocalD1('data/readings.sqlite');
await migrateLocal(db);
try{const actual=await fetchECB();await save(db,actual);const b=await board(db);await writeFile('data/actual-board.json',JSON.stringify(b,null,2));
 const response=await fetch(HISTORY_URL,{signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error('history HTTP '+response.status);const raw=await response.text(),points=parseRates(raw);const h={source_url:HISTORY_URL,fetched_at:new Date().toISOString(),raw_sha256:createHash('sha256').update(raw).digest('hex'),calculation:'round4(EUR/KRW ÷ EUR/USD)',points};await writeFile('data/history-original.xml',raw);await writeFile('public/chart-history.json',JSON.stringify(h,null,2));
 console.log(JSON.stringify({source_url:actual.reading.source_url,source_date:actual.source_date,eur_usd:actual.eur_usd,eur_krw:actual.eur_krw,value:actual.reading.normalized_value,record_date:actual.reading.record_date,fetched_at:actual.reading.fetched_at,published_at:actual.published_at,raw_sha256:actual.raw_sha256,real_daily_rows:b.rows.length,history_points:points.length}));
}finally{db.close();}
