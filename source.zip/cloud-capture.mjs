import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {resolve} from 'node:path';
import {LocalD1} from './local-db.mjs';import {migrateLocal} from './migrate-local.mjs';
import {importStore,exportStore} from './lib/durable-store.mjs';
import {observe,fullBoard,readState,writeState} from './lib/monitor.mjs';
import {comparison} from './lib/ecb.mjs';

const statePath=resolve(process.env.BOARD_STATE||'records/state.json');
const outputPath=resolve(process.env.BOARD_OUTPUT||'cloud/site');
await mkdir(outputPath,{recursive:true});await mkdir(resolve(statePath,'..'),{recursive:true});
const db=new LocalD1(':memory:');await migrateLocal(db);
let previous=null;
async function atomic(file,value){await writeFile(file+'.tmp',JSON.stringify(value,null,2)+'\n');await rename(file+'.tmp',file);}
try{
 try{previous=JSON.parse(await readFile(statePath,'utf8'));await importStore(db,previous);}catch(e){if(e.code!=='ENOENT')throw e;}
 // The cloud schedule is managed by its host, not a public visitor toggle.
 const monitor=await readState(db,'monitor');if(monitor&&!monitor.enabled)await writeState(db,'monitor',{...monitor,enabled:true,next_attempt:new Date().toISOString()});
 const force=process.env.FORCE_OBSERVATION==='1';
 await observe(db,{automatic:!force,force});
 const now=new Date().toISOString(),b=await fullBoard(db,now);
 const snapshot={...b,runtime:'cloud_snapshot',snapshot_at:now,collection_host:'GitHub Actions',schedule:'17,47 * * * * UTC',schedule_grace_minutes:90,assessment_rows:b.rows.slice(0,2),assessment_delta:comparison(b.rows.slice(0,2))};
 const history=await readState(db,'history');
 const exported=await exportStore(db,now);
 if(!previous||JSON.stringify(previous.tables)!==JSON.stringify(exported.tables))await atomic(statePath,exported);
 if(history){const {raw,...safe}=history;await atomic(resolve(outputPath,'chart-history.json'),safe);}
 await atomic(resolve(outputPath,'board.json'),snapshot);
 console.log(JSON.stringify({runtime:snapshot.runtime,snapshot_at:now,source_date:b.latest?.source_date,record_date:b.latest?.reading.record_date,rows:b.rows.length,status:b.status,next_attempt:b.monitor.next_attempt,forward_evaluations:b.learning.forward_count}));
}finally{db.close();}
