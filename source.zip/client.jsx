import {createRoot} from 'react-dom/client';
import Home from './app/page.jsx';import './app/globals.css';
createRoot(document.getElementById('root')).render(<Home/>);
