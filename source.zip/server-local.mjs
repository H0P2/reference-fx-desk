import http from 'node:http';import {mkdir,readFile,writeFile,rename} from 'node:fs/promises';import path from 'node:path';import worker from './worker.mjs';import {LocalD1} from './local-db.mjs';import {migrateLocal} from './migrate-local.mjs';import {fullBoard,startObserver} from './lib/monitor.mjs';
await mkdir('data',{recursive:true});const db=new LocalD1('data/readings.sqlite');await migrateLocal(db);
const port=Number(process.env.FX_LOCAL_PORT||8897),root=path.resolve('dist/client');
const assets={async fetch(request){const u=new URL(request.url);let file;try{file=path.resolve(root,'.'+decodeURIComponent(u.pathname==='/'?'/index.html':u.pathname));}catch{return new Response('Invalid path',{status:400});}if(!file.startsWith(root+path.sep))return new Response('Forbidden',{status:403});try{const bytes=await readFile(file);const type={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.zip':'application/zip'}[path.extname(file)]||'application/octet-stream';return new Response(bytes,{headers:{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}catch{return new Response('Not found',{status:404});}}};
let snapshots=Promise.resolve();
function snapshot(){snapshots=snapshots.catch(()=>{}).then(async()=>{const b=await fullBoard(db);await writeFile('data/actual-board.json.tmp',JSON.stringify({...b,runtime:'local_process'},null,2));await rename('data/actual-board.json.tmp','data/actual-board.json');});return snapshots;}
const server=http.createServer(async(req,res)=>{try{
 const url='http://127.0.0.1:'+port+req.url,chunks=[];let bytes=0;
 for await(const chunk of req){bytes+=chunk.length;if(bytes>256){res.writeHead(413);res.end();return;}chunks.push(chunk);}
 const body=chunks.length?Buffer.concat(chunks):undefined;
 const request=new Request(url,{method:req.method,headers:req.headers,...(body?{body}:{} )});
 const response=await worker.fetch(request,{DB:db,ASSETS:assets,OBSERVER_RUNTIME:'local_process'});
 res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 if(req.method==='POST'&&response.status===200)await snapshot();
 }catch{if(!res.headersSent){res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'storage_unavailable'}));}else if(!res.writableEnded)res.end();}});
const observer=startObserver(db,{onSnapshot:snapshot,onError:()=>console.error('Observation/storage unavailable; will retry in one minute.')});
server.listen(port,'127.0.0.1',()=>console.log('Automatic ECB observer: http://127.0.0.1:'+port+'/ (4-hour checks, next KST midnight, 15-minute failure retry)'));
let stopping=false;
async function stop(){if(stopping)return;stopping=true;await observer.stop();await snapshots.catch(()=>{});server.close(()=>{db.close();process.exit(0);});}process.once('SIGTERM',stop);process.once('SIGINT',stop);
