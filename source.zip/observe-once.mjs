import {mkdir,writeFile,rename} from 'node:fs/promises';
import {LocalD1} from './local-db.mjs';
import {migrateLocal} from './migrate-local.mjs';
import {observe,readState} from './lib/monitor.mjs';
await mkdir('data',{recursive:true});const db=new LocalD1('data/readings.sqlite');await migrateLocal(db);
try{
 const b=await observe(db);
 await writeFile('data/actual-board.json.tmp',JSON.stringify({...b,runtime:'snapshot'},null,2));await rename('data/actual-board.json.tmp','data/actual-board.json');
 const history=await readState(db,'history');if(history){const {raw,...safe}=history;await writeFile('data/history-original.xml',raw);await writeFile('public/chart-history.json',JSON.stringify(safe,null,2));}
 console.log(JSON.stringify({value:b.latest?.reading.normalized_value,record_date:b.latest?.reading.record_date,actual_daily_rows:b.rows.length,monitor:b.monitor,learning:{samples:b.learning.samples,as_of:b.learning.as_of,selected:b.learning.selected,forecast:b.learning.pending,adaptive_mae:b.learning.adaptive_mae,baseline_mae:b.learning.baseline_mae,forward_count:b.learning.forward_count}},null,2));
}finally{db.close();}
