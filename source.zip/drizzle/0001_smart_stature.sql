CREATE TABLE `automation_state` (
	`id` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL
);
