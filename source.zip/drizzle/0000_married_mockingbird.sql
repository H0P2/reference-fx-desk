CREATE TABLE `feed_status` (
	`id` integer PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`checked_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `readings` (
	`signal_id` text NOT NULL,
	`record_date` text NOT NULL,
	`first_fetched_at` text NOT NULL,
	`last_fetched_at` text NOT NULL,
	`payload` text NOT NULL,
	PRIMARY KEY(`signal_id`, `record_date`)
);
--> statement-breakpoint
CREATE TABLE `request_gate` (
	`id` integer PRIMARY KEY NOT NULL,
	`allowed_at` integer NOT NULL
);
