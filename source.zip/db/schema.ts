import {sqliteTable,text,integer,primaryKey} from 'drizzle-orm/sqlite-core';
export const readings=sqliteTable('readings',{signalId:text('signal_id').notNull(),recordDate:text('record_date').notNull(),firstFetchedAt:text('first_fetched_at').notNull(),lastFetchedAt:text('last_fetched_at').notNull(),payload:text('payload').notNull()},t=>[primaryKey({columns:[t.signalId,t.recordDate]})]);
export const feedStatus=sqliteTable('feed_status',{id:integer('id').primaryKey(),code:text('code').notNull(),checkedAt:text('checked_at').notNull()});
export const requestGate=sqliteTable('request_gate',{id:integer('id').primaryKey(),allowedAt:integer('allowed_at').notNull()});
export const automationState=sqliteTable('automation_state',{id:text('id').primaryKey(),payload:text('payload').notNull()});
