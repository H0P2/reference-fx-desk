import {fullBoard,observe,setEnabled,readState} from './lib/monitor.mjs';
const json=(payload,status=200)=>Response.json(payload,{status,headers:{'Cache-Control':'no-store'}});
export default {async fetch(request,env){const url=new URL(request.url);
 if(url.pathname==='/api/board'&&request.method==='GET'){try{return json({...await fullBoard(env.DB),runtime:env.OBSERVER_RUNTIME||'request_only'});}catch{return json({error:'storage_unavailable'},503);}}
 if(url.pathname==='/api/refresh'&&request.method==='POST'){
  if(request.headers.get('origin')!==url.origin)return json({error:'origin'},403);
  try{return json({...await observe(env.DB),runtime:env.OBSERVER_RUNTIME||'request_only'});}catch{return json({error:'storage_unavailable'},503);}
 }
 if(url.pathname==='/api/monitor'&&request.method==='POST'){
  if(request.headers.get('origin')!==url.origin)return json({error:'origin'},403);
  // Public visitors can refresh, but cannot pause the shared observer for everybody.
  if(env.OBSERVER_RUNTIME!=='local_process')return json({error:'monitor_local_only'},403);
  if(Number(request.headers.get('content-length'))>256)return json({error:'invalid_input'},400);
  let input;try{const raw=await request.text();if(raw.length>256)throw Error();input=JSON.parse(raw);if(typeof input.enabled!=='boolean'||Object.keys(input).length!==1)throw Error();}catch{return json({error:'invalid_input'},400);}
  try{return json({...await setEnabled(env.DB,input.enabled),runtime:env.OBSERVER_RUNTIME||'request_only'});}catch{return json({error:'storage_unavailable'},503);}
 }
 if(url.pathname==='/chart-history.json'&&request.method==='GET'){try{const history=await readState(env.DB,'history');if(history){const {raw,...safe}=history;return json(safe);}}catch{} }
 if(url.pathname.startsWith('/api/'))return json({error:'not_found'},404);
 return env.ASSETS.fetch(request);
},async scheduled(controller,env,ctx){ctx.waitUntil(observe(env.DB,{automatic:true}));}};
