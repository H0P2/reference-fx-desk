import {board} from './lib/d1.mjs';import {refreshBoard} from './lib/service.mjs';
const json=(payload,status=200)=>Response.json(payload,{status,headers:{'Cache-Control':'no-store'}});
export default {async fetch(request,env){const url=new URL(request.url);
 if(url.pathname==='/api/board'&&request.method==='GET'){try{return json(await board(env.DB));}catch{return json({error:'storage_unavailable'},503);}}
 if(url.pathname==='/api/refresh'&&request.method==='POST'){
  if(request.headers.get('origin')!==url.origin)return json({error:'origin'},403);
  try{return json(await refreshBoard(env.DB));}catch{return json({error:'storage_unavailable'},503);}
 }
 if(url.pathname.startsWith('/api/'))return json({error:'not_found'},404);
 return env.ASSETS.fetch(request);
}};
