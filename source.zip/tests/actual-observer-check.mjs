// Actual ECB requests; isolated storage. No synthetic clock or financial transaction.
import assert from 'node:assert/strict';import {mkdir,writeFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
import {LocalD1} from '../local-db.mjs';import {migrateLocal} from '../migrate-local.mjs';
import {startObserver,fullBoard,readState,setEnabled} from '../lib/monitor.mjs';import {parseRates} from '../lib/ecb.mjs';
const db=new LocalD1(':memory:');await migrateLocal(db);let error=null;
const observer=startObserver(db,{onError:e=>{error=e;}});
try{
 await observer.tick();if(error)throw error;
 const first=await fullBoard(db);assert.equal(first.status.error_code,'none');assert.equal(first.monitor.events.at(-1).kind,'automatic');assert.equal(first.rows.length,1);assert.ok(first.learning.samples>=20);
 const history=await readState(db,'history');assert.equal(history.raw_sha256,createHash('sha256').update(history.raw).digest('hex'));
 assert.ok(Date.parse(first.learning.pending.issued_at)>=Date.parse(history.fetched_at));assert.ok(Date.parse(first.learning.pending.issued_at)>=Date.parse(first.latest.reading.fetched_at));
 const source=parseRates(history.raw).filter(p=>p.date<=first.latest.source_date);for(const point of first.learning.points){const original=source.find(p=>p.date===point.date);if(original)assert.equal(point.value,original.value);}
 await observer.tick();const second=await fullBoard(db);assert.equal(second.monitor.attempts,first.monitor.attempts);assert.equal(second.learning.updates,first.learning.updates);assert.deepEqual(second.learning.pending,first.learning.pending);
 await setEnabled(db,false);await observer.tick();assert.equal((await fullBoard(db)).monitor.enabled,false);
 const evidence={result:'PASS',kind:'actual_automatic_observer_check',fetched_at:first.latest.reading.fetched_at,record_date:first.latest.reading.record_date,source_date:first.latest.source_date,actual_daily_rows:1,learning_samples:first.learning.samples,history_source_url:history.source_url,history_raw_sha256:history.raw_sha256,forward_count:0,checks:['automatic actual source request','history XML hash and normalized point equality','scheduled duplicate tick makes no new request','issued forecast unchanged','pause stops automatic checks'],submission_second_date:false};
 await mkdir('.sites-runtime',{recursive:true});await writeFile('.sites-runtime/actual-observer-check.json',JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence));
}finally{await observer.stop();db.close();}
